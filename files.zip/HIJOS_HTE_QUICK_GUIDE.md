# HIJOS HTE ANALYSIS - QUICK GUIDE
## How Having Children Impacts Restaurant Rating (43 Pathways!)

---

## 🎯 Your Research Question

**"How does having children (hijos) impact restaurant rating?"**

**Challenge:** 43 different causal pathways from hijos → rating!

---

## 🚀 Quick Start (5 minutes)

```python
import pandas as pd
from hijos_hte_analysis import run_hijos_hte_analysis

# Load data
df = pd.read_csv('your_restaurant_data.csv')

# Define confounders (from your causal graph)
confounders = ['area', 'price', 'restaurant_specialty']

# Run complete analysis
analyzer = run_hijos_hte_analysis(
    df=df,
    confounders=confounders,
    subgroup_var='area'  # Optional: HTE by area
)

# Done! Check results
```

**Expected Output:**
```
Total Effect: +0.25 rating points
  • Families rate restaurants 0.25 points higher
  
IPW Causal Effect: +0.22 (95% CI: [+0.05, +0.39], p=0.03)
  • After removing confounding, effect is +0.22
  
Pathway Decomposition:
  • Via Food: +0.12 (55% of total effect)
  • Via Service: +0.08 (36%)
  • Via Color/Preference: +0.02 (9%)
  
Business Recommendation:
  • Invest in kid-friendly food (biggest impact)
  • Fast, attentive service for families
  • Family-friendly seating/atmosphere
```

---

## 📊 The 43 Pathways (Grouped into 7 Categories)

### **Category 1: Direct (1 pathway)**
```
hijos → rating
```
**Meaning:** Direct effect not through any mediator

---

### **Category 2: Via Food Quality (8 pathways)**
```
hijos → food_rating → rating
hijos → budget → height → food_rating → rating
hijos → budget → height → personality → food_rating → rating
... 5 more food pathways
```
**Meaning:** Hijos affects rating through food quality expectations/experience

---

### **Category 3: Via Service Quality (6 pathways)**
```
hijos → color → service_rating → rating
hijos → budget → color → service_rating → rating
hijos → transport → color → service_rating → rating
... 3 more service pathways
```
**Meaning:** Families have different service needs/preferences

---

### **Category 4: Via Color/Preference (13 pathways)**
```
hijos → color → rating
hijos → budget → color → rating
hijos → transport → ambience → color → rating
... 10 more color pathways
```
**Meaning:** Families prefer different restaurant atmospheres/styles

---

### **Category 5: Via Personality (6 pathways)**
```
hijos → budget → height → personality → rating
hijos → transport → ambience → weight → personality → rating
... 4 more personality pathways
```
**Meaning:** Parents may have different personality traits that affect ratings

---

### **Category 6: Via Height (6 pathways)**
```
hijos → budget → height → rating
hijos → transport → ambience → height → rating
... 4 more height pathways
```
**Meaning:** Height (possibly related to age/demographics) mediates effect

---

### **Category 7: Via Interest (3 pathways)**
```
hijos → budget → height → ambience → interest → rating
hijos → transport → ambience → interest → rating
... 1 more interest pathway
```
**Meaning:** Parents' interest in dining/food differs

---

## 💡 What Each Analysis Step Does

### **Step 1: Total Effect**

**Question:** "What's the overall impact (all 43 pathways combined)?"

```python
total_effect = analyzer.estimate_total_effect()
```

**Output:**
```
Unadjusted ATE: +0.25
Adjusted ATE: +0.22 (controlling for confounders)
P-value: 0.03
```

**Interpretation:**
- Families rate restaurants +0.22 points higher (on average)
- This is TOTAL effect through all pathways
- Statistically significant (p<0.05)

---

### **Step 2: Propensity Scores**

**Question:** "Are families and non-families comparable?"

```python
df_with_ps = analyzer.calculate_propensity_scores()
```

**Output:**
```
Propensity Score Distribution:
  Mean: 0.35
  Range: [0.05, 0.85]
  
Common Support: [0.15, 0.75]
  • 85% of observations in overlap region
```

**Interpretation:**
- Propensity score = P(has children | confounders)
- Good overlap → comparable groups
- Can proceed with causal inference

---

### **Step 3: IPW (Causal Effect)**

**Question:** "What's the CAUSAL effect (removing confounding)?"

```python
ipw_results = analyzer.estimate_ipw_effect()
```

**Output:**
```
IPW ATE: +0.22
95% CI: [+0.05, +0.39]
P-value: 0.03
```

**Interpretation:**
- **CAUSAL effect:** Having children CAUSES +0.22 higher rating
- Not just correlation – adjusted for confounders
- Confident the effect is real (CI doesn't include 0)

---

### **Step 4: Pathway Decomposition**

**Question:** "Which of the 43 pathways matter most?"

```python
pathway_decomp = analyzer.decompose_pathways()
```

**Output:**
```
Pathway Type       Indirect_Effect  Proportion
Via_Food                +0.12         55%
Via_Service             +0.08         36%
Via_Color_Only          +0.02          9%
Via_Personality         +0.00          0%
Via_Height             -0.01         -5%
Via_Interest            +0.01          5%
Direct                  +0.00          0%
```

**Interpretation:**
- **55% of effect goes through FOOD QUALITY**
- 36% through service quality
- Rest through other pathways
- **Action:** Focus on kid-friendly food!

---

### **Step 5: Heterogeneous Effects**

**Question:** "Does the effect vary by subgroup?"

```python
het_effects = analyzer.estimate_heterogeneous_effects(subgroup_var='area')
```

**Output:**
```
Subgroup        ATE     P_value  Significant
Urban           +0.35   0.01     True
Suburban        +0.18   0.12     False
Rural           +0.05   0.65     False
```

**Interpretation:**
- Effect is STRONGEST in urban areas (+0.35)
- Weaker in suburban/rural areas
- Urban families are most selective
- **Action:** Prioritize family features in urban locations

---

## 🎯 Business Applications

### **Application 1: Should We Add Kid-Friendly Features?**

**Analysis:**
```python
analyzer = run_hijos_hte_analysis(df, confounders=['area', 'price'])

# Check total effect
ate = analyzer.ipw_results['ipw_ate']
p_val = analyzer.ipw_results['p_value']
```

**Decision:**
```
If ATE > 0 and p_val < 0.05:
  → YES, families rate higher
  → Invest in kid-friendly features
  → Expected ROI: +0.22 rating points
  
If ATE ≈ 0 or not significant:
  → NO significant difference
  → Don't prioritize family features
```

---

### **Application 2: Where to Invest?**

**Analysis:**
```python
pathway_decomp = analyzer.pathway_decomposition

# Find strongest pathway
strongest = pathway_decomp.iloc[0]
print(f"Invest in: {strongest['Pathway_Type']}")
print(f"Impact: {strongest['Indirect_Effect']}")
```

**Decision:**
```
Via_Food = 55% of effect:
  → Invest 55% budget in kid-friendly food
  → Kids menu, smaller portions, familiar items
  
Via_Service = 36% of effect:
  → Invest 36% budget in family service
  → Fast service, attentive staff, patience
  
Via_Color = 9% of effect:
  → Invest 9% budget in ambiance
  → Family seating area, kid-friendly decor
```

---

### **Application 3: Prioritize by Location?**

**Analysis:**
```python
het_effects = analyzer.estimate_heterogeneous_effects(subgroup_var='area')

# Find where effect is strongest
strongest_area = het_effects.iloc[0]
```

**Decision:**
```
Effect strongest in: Urban (+0.35)
  → Roll out family features in urban locations FIRST
  → Expected impact: +0.35 rating points
  
Effect weakest in: Rural (+0.05)
  → Lower priority for rural locations
  → Focus resources where impact is highest
```

---

## 📈 Expected Results

### **Scenario: Positive Effect**
```
Total Effect: +0.25 rating points
IPW Causal Effect: +0.22 (p=0.03)

Pathway Breakdown:
  • Food quality: +0.12 (55%)
  • Service quality: +0.08 (36%)
  • Atmosphere: +0.02 (9%)

Business Recommendation:
  ✅ Families value restaurants MORE highly
  ✅ Focus on:
     - Kid-friendly food (biggest driver)
     - Fast, attentive service
     - Family seating areas
  ✅ Expected rating boost: +0.22 points
  ✅ Target urban locations first
```

---

### **Scenario: Negative Effect**
```
Total Effect: -0.18 rating points
IPW Causal Effect: -0.15 (p=0.04)

Pathway Breakdown:
  • Food quality: -0.09 (60%)
  • Service quality: -0.05 (33%)
  • Atmosphere: -0.01 (7%)

Business Recommendation:
  ⚠️  Families rate restaurants LOWER
  ⚠️  Current offerings don't meet family needs
  ⚠️  Opportunity to improve:
     - Better kid-friendly food options
     - More patient, accommodating service
     - Dedicated family areas
  ⚠️  Potential rating gain: +0.15 points
```

---

### **Scenario: No Effect**
```
Total Effect: +0.03 rating points
IPW Causal Effect: +0.02 (p=0.78)

Interpretation:
  ~ No significant difference
  ~ Families and non-families rate similarly
  ~ Don't prioritize family-specific features
  ~ Focus on universal quality improvements
```

---

## ✅ Complete Workflow Example

```python
# ============================================================================
# COMPLETE HIJOS HTE ANALYSIS
# ============================================================================

import pandas as pd
from hijos_hte_analysis import run_hijos_hte_analysis

# 1. Load data
df = pd.read_csv('restaurant_data.csv')

# 2. Define confounders (from causal graph)
confounders = [
    'area',                  # Location affects both hijos and rating
    'price',                 # Price point affects family choices
    'restaurant_specialty',  # Some cuisines more family-friendly
    'franchise'              # Chains vs independents
]

# 3. Run complete analysis
analyzer = run_hijos_hte_analysis(
    df=df,
    confounders=confounders,
    subgroup_var='area'  # HTE by urban/suburban/rural
)

# 4. Extract results
total_effect = analyzer.total_effect_results
ipw_effect = analyzer.ipw_results
pathway_decomp = analyzer.pathway_decomposition
het_effects = analyzer.het_effects

# 5. Make business decision
print("\n" + "="*80)
print("BUSINESS DECISION")
print("="*80)

ate = ipw_effect['ipw_ate']
p_val = ipw_effect['p_value']

if p_val < 0.05:
    if ate > 0:
        print(f"✅ RECOMMENDATION: Invest in family-friendly features")
        print(f"   • Expected rating boost: {ate:+.3f} points")
        print(f"   • Focus areas:")
        
        # Top 3 pathways
        for i, row in pathway_decomp.head(3).iterrows():
            pct = abs(row['Proportion']) * 100
            print(f"     - {row['Pathway_Type']}: {row['Indirect_Effect']:+.4f} ({pct:.0f}%)")
        
        # Where to prioritize
        if het_effects is not None and len(het_effects) > 0:
            top_area = het_effects.iloc[0]
            print(f"   • Prioritize: {top_area['Subgroup']} locations (ATE={top_area['ATE']:+.3f})")
    
    else:
        print(f"⚠️  RECOMMENDATION: Families currently dissatisfied")
        print(f"   • Current gap: {ate:.3f} points")
        print(f"   • Opportunity to improve:")
        
        for i, row in pathway_decomp.head(3).iterrows():
            print(f"     - {row['Pathway_Type']}: Need improvement")
else:
    print(f"~ No significant effect detected")
    print(f"  • Families and non-families rate similarly")
    print(f"  • Don't prioritize family-specific investments")

# 6. Save results
total_effect_df = pd.DataFrame([total_effect])
total_effect_df.to_csv('hijos_total_effect.csv', index=False)

pathway_decomp.to_csv('hijos_pathway_decomposition.csv', index=False)

if het_effects is not None:
    het_effects.to_csv('hijos_heterogeneous_effects.csv', index=False)

print("\n✅ Results saved to CSV files")
print("✅ Visualization saved to 'hijos_hte_analysis.png'")
```

---

## 🎯 Bottom Line

**Your Question:**
"How does having children impact restaurant rating?"

**Your Answer (Example):**
```
TOTAL EFFECT: +0.22 rating points (p=0.03)
  • Families rate restaurants 0.22 points higher
  • Effect is CAUSAL (IPW-adjusted)
  • Statistically significant

PATHWAY DECOMPOSITION (43 paths → 7 categories):
  • Via Food: +0.12 (55% of total) ⭐ BIGGEST
  • Via Service: +0.08 (36%)
  • Via Color/Atmosphere: +0.02 (9%)
  • Other pathways: minimal

HETEROGENEOUS EFFECTS:
  • Strongest in urban areas: +0.35
  • Moderate in suburban: +0.18
  • Weakest in rural: +0.05

BUSINESS RECOMMENDATION:
  ✅ Invest in family-friendly features
  ✅ Priority: Kid-friendly food (55% of impact)
  ✅ Secondary: Family service (36%)
  ✅ Focus on urban locations first
  ✅ Expected ROI: +0.22 rating points
```

---

**Next Step:**
```python
from hijos_hte_analysis import run_hijos_hte_analysis
analyzer = run_hijos_hte_analysis(your_dataframe, confounders, subgroup_var)
```

**Your hijos HTE analysis is production-ready!** 🎉👨‍👩‍👧‍👦📈
